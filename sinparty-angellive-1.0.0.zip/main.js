(function () {
  "use strict";

  // 可选：部署 worker.js 后填写地址；留空时插件会直接请求上游接口。
  var WORKER_BASE_URL = "https://REPLACE-WITH-YOUR-WORKER.workers.dev";
  var LIVE_TYPE = "sinparty-live";
  var roomCache = {};

  function workerURL(params) {
    var query = Object.keys(params || {}).map(function (key) {
      return encodeURIComponent(key) + "=" + encodeURIComponent(String(params[key]));
    }).join("&");
    return WORKER_BASE_URL.replace(/\/+$/, "") + "/" + (query ? "?" + query : "");
  }

  async function httpJSON(url, headers) {
    var response = await Host.http.request({
      url: url,
      method: "GET",
      timeout: 20,
      headers: headers || { "Accept": "application/json" }
    });
    if (response.status < 200 || response.status >= 300) {
      Host.raise("UPSTREAM", "请求失败: HTTP " + response.status, { url: url });
    }
    try {
      var data = JSON.parse(response.bodyText || "{}");
      if (data.error) Host.raise("UPSTREAM", String(data.error), {});
      return data;
    } catch (error) {
      if (String(error).indexOf("LP_PLUGIN_ERROR:") >= 0) throw error;
      Host.raise("PARSE", "Worker 返回了无效 JSON", {});
    }
  }

  function upstreamHeaders() {
    return {
      "Accept": "application/json",
      "Referer": "https://sinparty.com/",
      "Origin": "https://sinparty.com",
      "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
    };
  }

  async function directRequest(params) {
    if (!params.ac || params.ac === "class") {
      return { class: [
        { type_id: "all", type_name: "精选" },
        { type_id: "girls", type_name: "女生" },
        { type_id: "guys", type_name: "男生" },
        { type_id: "couples", type_name: "情侣" },
        { type_id: "trans", type_name: "变性人" }
      ] };
    }

    if (params.ac === "category") {
      var query = [
        "page=" + encodeURIComponent(String(params.pg || 1)),
        "per_page=40",
        "od=desc"
      ];
      var category = String(params.t || "all");
      if (category === "couples") query.push("category%5B%5D=couples");
      else if (category === "trans") {
        query.push("category%5B%5D=trans");
        query.push("gender%5B%5D=t");
      } else if (category === "guys") query.push("gender%5B%5D=m");
      else {
        query.push("gender%5B%5D=f");
        query.push("so=has_straight");
      }

      var raw = await httpJSON(
        "https://api.sinparty.com/v2/web/live-cams/web-rtc?" + query.join("&"),
        upstreamHeaders()
      );
      var items = raw.data && raw.data.items ? raw.data.items : [];
      return { page: Number(params.pg || 1), list: items.map(function (item) {
        var nativeRoom = Boolean(item.creator_user_hash);
        var key = nativeRoom ? item.creator_user_hash : item.Nickname;
        if (!key) return null;
        var poster = item.thumbnail_url || item.Thumbnail || item.Snapshot || "";
        if (!poster && item.poster_set_template) {
          poster = String(item.poster_set_template).replace("{size}", "360");
        }
        return {
          vod_id: (nativeRoom ? "native|" : "external|") + key,
          vod_name: item.title || item.Nickname || "Live",
          vod_pic: poster,
          vod_remarks: "🔥" + String(item.viewers || 0)
        };
      }).filter(Boolean) };
    }

    if (params.ac === "detail") {
      var id = String(params.ids || "");
      var separator = id.indexOf("|");
      var mode = separator >= 0 ? id.slice(0, separator) : "";
      var key = separator >= 0 ? id.slice(separator + 1) : "";
      var playURL = "";
      if (mode === "external") {
        var extHeaders = upstreamHeaders();
        extHeaders.sitedomain = "sinpartylive.com";
        extHeaders.tenantid = "SM";
        var ext = await httpJSON(
          "https://manifest-server.naiadsystems.com/live/s:" + encodeURIComponent(key) + ".json?vdc=true",
          extHeaders
        );
        var hls = ext.formats && ext.formats["mp4-hls"] ? ext.formats["mp4-hls"] : {};
        var encodings = hls.encodings || [];
        playURL = hls.manifest || (encodings.length ? encodings[encodings.length - 1].location : "") || "";
      } else if (mode === "native") {
        var nativeData = await httpJSON(
          "https://api.sinparty.com/v2/web/live-cams/web-rtc/" + encodeURIComponent(key),
          upstreamHeaders()
        );
        playURL = nativeData.data && nativeData.data.playback_url ? nativeData.data.playback_url : "";
      }
      return { list: [{ vod_id: id, vod_play_url: playURL ? "高清$" + playURL : "" }] };
    }

    Host.raise("REQUEST", "不支持的请求类型", { ac: params.ac || "" });
  }

  async function requestJSON(params) {
    if (!WORKER_BASE_URL || WORKER_BASE_URL.indexOf("REPLACE-WITH-YOUR-WORKER") >= 0) {
      return directRequest(params || {});
    }
    return httpJSON(workerURL(params), { "Accept": "application/json" });
  }

  function roomFromVod(vod) {
    var room = {
      userName: String(vod.vod_name || "Live"),
      roomTitle: String(vod.vod_name || "Live"),
      roomCover: String(vod.vod_pic || ""),
      userHeadImg: String(vod.vod_pic || ""),
      liveState: "1",
      userId: String(vod.vod_id || ""),
      roomId: String(vod.vod_id || ""),
      liveWatchedCount: String(vod.vod_remarks || "").replace(/[^0-9]/g, "") || "0"
    };
    roomCache[room.roomId] = room;
    return room;
  }

  async function resolveStream(roomId) {
    var data = await requestJSON({ ac: "detail", ids: roomId });
    var item = data.list && data.list[0];
    var raw = item && item.vod_play_url ? String(item.vod_play_url) : "";
    var separator = raw.indexOf("$");
    var streamURL = separator >= 0 ? raw.slice(separator + 1) : raw;
    if (!/^https?:\/\//i.test(streamURL)) {
      Host.raise("OFFLINE", "直播间当前未开播或无法取得播放地址", { roomId: roomId });
    }
    return streamURL;
  }

  globalThis.LiveParsePlugin = {
    apiVersion: 1,

    getCategories: async function () {
      var data = await requestJSON({ ac: "class" });
      var categories = (data.class || []).map(function (item) {
        return {
          id: String(item.type_id),
          parentId: "sinparty",
          title: String(item.type_name),
          icon: "",
          biz: ""
        };
      });
      return [{
        id: "sinparty",
        title: "直播分类",
        icon: "",
        biz: "",
        subList: categories
      }];
    },

    getRooms: async function (payload) {
      var data = await requestJSON({
        ac: "category",
        t: payload.id || "all",
        pg: payload.page || 1
      });
      return (data.list || []).map(roomFromVod);
    },

    getPlayback: async function (payload) {
      var streamURL = await resolveStream(String(payload.roomId || ""));
      return [{
        cdn: "sinparty",
        displayName: "直播线路",
        qualitys: [{
          roomId: String(payload.roomId || ""),
          title: "高清",
          qn: 10000,
          url: streamURL,
          liveCodeType: "m3u8",
          liveType: LIVE_TYPE,
          userAgent: "Mozilla/5.0 (AppleTV; Apple TV) AppleWebKit/605.1.15",
          headers: { "Referer": "https://sinparty.com/" },
          playbackHints: {
            streamFormat: "hlsLive",
            selectionBehavior: "direct"
          }
        }]
      }];
    },

    getLiveState: async function (payload) {
      try {
        await resolveStream(String(payload.roomId || ""));
        return { liveState: "1" };
      } catch (_) {
        return { liveState: "0" };
      }
    },

    getRoomDetail: async function (payload) {
      var roomId = String(payload.roomId || "");
      return roomCache[roomId] || {
        userName: "SinParty Live",
        roomTitle: "实时直播",
        roomCover: "",
        userHeadImg: "",
        liveState: "1",
        userId: String(payload.userId || roomId),
        roomId: roomId,
        liveWatchedCount: "0"
      };
    }
  };
})();
